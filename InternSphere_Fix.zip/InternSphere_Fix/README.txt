INTERN SPHERE - AUTOMATED EVALUATION VERSION (browser + Java + SQLite)
=======================================================================
Needs only a JDK 17+ (adoptium.net). No MySQL, no internet.

START
  Windows:    double-click start_web.bat
  Mac/Linux:  sh start_web.sh
  VS Code:    open InternSphereServer.java and press Run
  Then open   http://localhost:8080   (it also opens automatically)
Data is stored in intern_sphere_web.db (SQLite). Delete that file to reset the demo.
Opening web/index.html directly as a file also works (browser storage instead of SQLite).

WHAT CHANGED
  The mentor no longer approves or rejects. The mentor assigns a project with a
  DESCRIPTION and REQUIREMENTS. When the student uploads a file the system:
    1. reads the file (PDF incl. compressed PDFs, DOCX, TXT/MD/CSV/HTML/code files)
    2. compares its text with each requirement and the project description
       (keyword + stem + synonym matching; words that identify one requirement count more)
    3. shows Match Score, OK / NOT OK, matched and missing requirements, summary, feedback
    4. stores everything in the database (report history) and notifies student + mentor
  Scores:  >= 90% OK | 70-89% OK with minor improvement | < 70% NOT OK
           (Manager > Overview > "Automatic Evaluation Settings" changes these numbers)
  Images, scanned PDFs and unsupported types show: "Unable to automatically analyze this file type"
  (never a false match). NOT OK / minor / unreadable results can be resubmitted; history is kept.
  Note: this is transparent keyword matching, not a language-model AI. It checks that requirement
  wording and its related terms appear in the report; it does not judge code quality.

DEMO SCRIPT (about 3 minutes)
  1. priya@intern.com / mentor123 > Management > "Assign New Project" > Fill example > Assign
  2. arun@intern.com / student123 > Submission > pick the new report > choose
     "demo: strong match" (or weak/partial) > Submit Demo File   - or upload your own PDF/DOCX/TXT
  3. Instantly: score, OK/NOT OK, matched and missing requirements, feedback
  4. Back as Priya: Student Submissions table shows score + result; View / Download / Evaluation
  5. manager@internsphere.com / manager123 > Database tab: live SQL on the tables (reports has
     match_score, result, requirements, eval_json)

LOGINS
  manager@internsphere.com / manager123
  priya@intern.com, ravi@intern.com / mentor123
  arun@, bharathi@, charu@, dinesh@, ezhil@, fathima@  (all @intern.com) / student123

FOLDERS
  web/index.html            the interface
  InternSphereServer.java   Java web server + SQLite storage (no frameworks)
  lib/                      SQLite driver jar
  old_desktop_version/      earlier Swing app + CreateDatabase (still the manual approve flow)


NEW WORKFLOW ADDITIONS
  Mentor Progress Report:
    The mentor can open "Progress Report", review auto-generated student metrics,
    add mentor remarks, and submit a periodic report to the manager.
  Manager monitoring:
    Management now shows mentor report status plus automatic risk/process alerts.
  Risk rules:
    - repeated NOT OK results for a student
    - overdue student submissions
    - repeated missing requirements across multiple students under one mentor
    - missing mentor progress report after the manager deadline
    These are review flags only; the system does not automatically blame the mentor.
  Database:
    mentor_reports and risk_alerts are stored in SQLite and are visible in the
    manager Database tab.

WINDOWS DESKTOP NOTIFICATIONS
  Install BurntToast once in Windows PowerShell (CurrentUser scope):
    Install-Module -Name BurntToast -Scope CurrentUser
  Test it with:
    New-BurntToastNotification -Text "InternSphere", "Desktop notifications are working"
  Keep the Java server window open. When a new in-app notification is saved,
  the server runs notify-toast.ps1 and displays a Windows toast. The browser
  tab may be closed, but the Java server must remain running. This is a local
  laptop notification feature, not a cloud push service. Automatic scheduled
  reminders while nobody is using the app are not included in this build.

IMPORTANT FILE LOCATIONS
  InternSphereServer.java must be in this folder, beside start_web.bat.
  The web page served by the server is web/index.html.
  Keep notify-toast.ps1 in this folder too.
