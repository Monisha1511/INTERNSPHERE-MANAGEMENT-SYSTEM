@echo off
cd /d "%~dp0"
if not exist out mkdir out
javac -cp "lib/*" -d out InternSphereServer.java
java -cp "out;lib/*" InternSphereServer
pause
