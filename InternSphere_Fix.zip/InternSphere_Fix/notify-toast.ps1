param(
    [string]$Title = "InternSphere",
    [string]$Message = "You have a new notification."
)

$ErrorActionPreference = "Stop"
try {
    Import-Module BurntToast -ErrorAction Stop
    New-BurntToastNotification -Text $Title, $Message
    exit 0
} catch {
    [Console]::Error.WriteLine("InternSphere desktop notification failed: $($_.Exception.Message)")
    exit 1
}
