#!/bin/sh
cd "$(dirname "$0")"
mkdir -p out
javac -cp "lib/*" -d out InternSphere.java
java -cp "out:lib/*" InternSphere
