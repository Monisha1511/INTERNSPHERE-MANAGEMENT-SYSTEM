import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/**
 * Intern Sphere - database creation program (SQLite via JDBC).
 *
 * Creates InternSphereDB.db in the current folder with:
 *   users, reports, report_log, notifications  (+ view pending_review_queue)
 * inserts the demo data, writes schema.sql, and prints every table.
 *
 * Compile:  javac CreateDatabase.java
 * Run:      java -cp ".:sqlite-jdbc-3.46.1.3.jar" CreateDatabase     (Windows: use ; instead of :)
 */
public class CreateDatabase {
    static final String DB_FILE = "InternSphereDB.db";

    static final String[] DDL = {
        "CREATE TABLE users (\n"
      + "  id         INTEGER PRIMARY KEY,\n"
      + "  email      TEXT NOT NULL UNIQUE,\n"
      + "  password   TEXT NOT NULL,\n"
      + "  name       TEXT NOT NULL,\n"
      + "  role       TEXT NOT NULL CHECK (role IN ('manager','mentor','student')),\n"
      + "  mentor_id  INTEGER REFERENCES users(id)   -- only students have a mentor\n"
      + ")",
        "CREATE TABLE reports (\n"
      + "  id          INTEGER PRIMARY KEY,\n"
      + "  student_id  INTEGER NOT NULL REFERENCES users(id),\n"
      + "  mentor_id   INTEGER NOT NULL REFERENCES users(id),\n"
      + "  project     TEXT NOT NULL,\n"
      + "  title       TEXT NOT NULL,\n"
      + "  assigned    TEXT NOT NULL,   -- yyyy-MM-dd\n"
      + "  deadline    TEXT NOT NULL,\n"
      + "  submitted   TEXT,            -- NULL until the student submits\n"
      + "  status      TEXT NOT NULL DEFAULT 'Pending'\n"
      + "              CHECK (status IN ('Pending','Pending Review','Approved','Have to Improve')),\n"
      + "  feedback    TEXT,            -- mentor feedback when status = 'Have to Improve'\n"
      + "  file_name   TEXT             -- submitted PDF / document\n"
      + ")",
        "CREATE TABLE report_log (\n"
      + "  id         INTEGER PRIMARY KEY AUTOINCREMENT,\n"
      + "  report_id  INTEGER NOT NULL REFERENCES reports(id),\n"
      + "  event_date TEXT NOT NULL,\n"
      + "  event      TEXT NOT NULL\n"
      + ")",
        "CREATE TABLE notifications (\n"
      + "  id         INTEGER PRIMARY KEY AUTOINCREMENT,\n"
      + "  user_id    INTEGER NOT NULL REFERENCES users(id),\n"
      + "  created    TEXT NOT NULL,\n"
      + "  message    TEXT NOT NULL,\n"
      + "  is_read    INTEGER NOT NULL DEFAULT 0\n"
      + ")",
        "CREATE INDEX idx_reports_student ON reports(student_id)",
        "CREATE INDEX idx_reports_mentor_status ON reports(mentor_id, status)",
        "CREATE VIEW pending_review_queue AS\n"
      + "  SELECT r.id, s.name AS student, m.name AS mentor, r.project, r.title, r.submitted, r.file_name\n"
      + "  FROM reports r JOIN users s ON s.id = r.student_id JOIN users m ON m.id = r.mentor_id\n"
      + "  WHERE r.status = 'Pending Review'"
    };

    public static void main(String[] args) throws Exception {
        Files.deleteIfExists(Paths.get(DB_FILE));
        try (Connection c = DriverManager.getConnection("jdbc:sqlite:" + DB_FILE)) {
            try (Statement st = c.createStatement()) { st.execute("PRAGMA foreign_keys = ON"); }
            c.setAutoCommit(false);
            try (Statement st = c.createStatement()) { for (String d : DDL) st.executeUpdate(d); }
            insertUsers(c); insertReports(c); insertNotifications(c);
            c.commit();
            writeSchemaFile();
            System.out.println("Database created: " + new File(DB_FILE).getAbsolutePath() + "\n");
            for (String t : new String[]{"users", "reports", "report_log", "notifications"}) dump(c, "SELECT * FROM " + t, "TABLE " + t);
            dump(c, "SELECT * FROM pending_review_queue", "VIEW pending_review_queue (what each mentor must review)");
            dump(c, "SELECT m.name AS mentor, COUNT(*) AS reports, SUM(r.status='Approved') AS approved, SUM(r.status='Pending Review') AS to_review, "
                  + "SUM(r.status='Have to Improve') AS returned, SUM(r.status='Pending') AS pending "
                  + "FROM reports r JOIN users m ON m.id = r.mentor_id GROUP BY m.name", "QUERY: report summary per mentor");
        }
    }

    static void insertUsers(Connection c) throws SQLException {
        Object[][] u = {
            {1, "manager@internsphere.com", "manager123", "Manager", "manager", null},
            {2, "priya@intern.com", "mentor123", "Priya Mentor", "mentor", null},
            {9, "ravi@intern.com", "mentor123", "Ravi Mentor", "mentor", null},
            {3, "arun@intern.com", "student123", "Arun Student", "student", 2},
            {4, "bharathi@intern.com", "student123", "Bharathi S", "student", 2},
            {5, "charu@intern.com", "student123", "Charulatha K", "student", 2},
            {6, "dinesh@intern.com", "student123", "Dinesh R", "student", 9},
            {7, "ezhil@intern.com", "student123", "Ezhil V", "student", 9},
            {8, "fathima@intern.com", "student123", "Fathima B", "student", 9}};
        try (PreparedStatement p = c.prepareStatement("INSERT INTO users VALUES (?,?,?,?,?,?)")) {
            for (Object[] r : u) { for (int i = 0; i < r.length; i++) p.setObject(i + 1, r[i]); p.executeUpdate(); }
        }
    }

    static void insertReports(Connection c) throws SQLException {
        Map<Integer, String[]> who = new HashMap<>();   // student id -> {name, project, mentor id}
        who.put(3, new String[]{"Arun Student", "Smart Notes Organizer", "2"});
        who.put(4, new String[]{"Bharathi S", "Student Skill Portfolio", "2"});
        who.put(5, new String[]{"Charulatha K", "Internship Task Tracker", "2"});
        who.put(6, new String[]{"Dinesh R", "Attendance Tracker", "9"});
        who.put(7, new String[]{"Ezhil V", "Library Management System", "9"});
        who.put(8, new String[]{"Fathima B", "Weather Dashboard", "9"});
        // studentId, title, assigned, deadline, submitted, status, feedback
        String[][] S = {
            {"4", "Research Summary", "2026-09-28", "2026-10-02", "2026-10-01", "Approved", null},
            {"5", "UI Prototype", "2026-09-29", "2026-10-03", "2026-10-02", "Approved", null},
            {"3", "Week 1 Report", "2026-10-01", "2026-10-04", "2026-10-03", "Approved", null},
            {"4", "Week 1 Report", "2026-10-01", "2026-10-05", "2026-10-05", "Pending Review", null},
            {"5", "Week 1 Report", "2026-10-01", "2026-10-05", "2026-10-04", "Have to Improve",
                "Please improve the project documentation and add screenshots of the implementation."},
            {"7", "Week 1 Report", "2026-10-01", "2026-10-05", "2026-10-04", "Approved", null},
            {"6", "Week 1 Report", "2026-10-02", "2026-10-06", "2026-10-06", "Pending Review", null},
            {"8", "Week 1 Report", "2026-10-02", "2026-10-06", "2026-10-06", "Have to Improve", "Add a clear README and explain how the data is refreshed."},
            {"3", "Mini Project", "2026-10-03", "2026-10-08", "2026-10-06", "Pending Review", null},
            {"5", "Final Project", "2026-10-04", "2026-10-10", null, "Pending", null},
            {"8", "Mini Project", "2026-10-04", "2026-10-11", null, "Pending", null},
            {"4", "Mini Project", "2026-10-05", "2026-10-11", null, "Pending", null},
            {"6", "Mini Project", "2026-10-05", "2026-10-12", null, "Pending", null},
            {"3", "Final Project", "2026-10-06", "2026-10-12", null, "Pending", null},
            {"7", "Final Project", "2026-10-06", "2026-10-13", null, "Pending", null}};
        try (PreparedStatement r = c.prepareStatement("INSERT INTO reports(id,student_id,mentor_id,project,title,assigned,deadline,submitted,status,feedback,file_name) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
             PreparedStatement l = c.prepareStatement("INSERT INTO report_log(report_id,event_date,event) VALUES (?,?,?)")) {
            int id = 0;
            for (String[] s : S) {
                String[] w = who.get(Integer.parseInt(s[0])); id++;
                String file = s[4] == null ? null : (w[0] + "_" + s[1]).replace(' ', '_') + ".pdf";
                Object[] v = {id, Integer.parseInt(s[0]), Integer.parseInt(w[2]), w[1], s[1], s[2], s[3], s[4], s[5], s[6], file};
                for (int i = 0; i < v.length; i++) r.setObject(i + 1, v[i]);
                r.executeUpdate();
                log(l, id, s[2], "Assigned by mentor");
                if (s[4] != null) log(l, id, s[4], "Submitted " + file);
                if (s[5].equals("Approved")) log(l, id, s[4], "Approved by mentor");
                if (s[5].equals("Have to Improve")) log(l, id, s[4], "Returned: Have to Improve - " + s[6]);
            }
        }
    }
    static void log(PreparedStatement l, int id, String date, String ev) throws SQLException {
        l.setInt(1, id); l.setString(2, date); l.setString(3, ev); l.executeUpdate();
    }

    static void insertNotifications(Connection c) throws SQLException {
        Object[][] n = {
            {3, "2026-10-07", "Your report 'Week 1 Report' (Smart Notes Organizer) was approved.", 1},
            {5, "2026-10-07", "'Week 1 Report' needs improvement: Please improve the project documentation and add screenshots of the implementation. Please resubmit.", 0},
            {2, "2026-10-06", "Arun Student submitted 'Mini Project' (Smart Notes Organizer). Ready for review.", 0},
            {2, "2026-10-05", "Bharathi S submitted 'Week 1 Report' (Student Skill Portfolio). Ready for review.", 0},
            {9, "2026-10-06", "Dinesh R submitted 'Week 1 Report' (Attendance Tracker). Ready for review.", 0},
            {4, "2026-10-05", "New project assigned: 'Mini Project'. Deadline: 11 Oct 2026", 0}};
        try (PreparedStatement p = c.prepareStatement("INSERT INTO notifications(user_id,created,message,is_read) VALUES (?,?,?,?)")) {
            for (Object[] r : n) { for (int i = 0; i < r.length; i++) p.setObject(i + 1, r[i]); p.executeUpdate(); }
        }
    }

    static void writeSchemaFile() throws IOException {
        StringBuilder sb = new StringBuilder("-- Intern Sphere database schema (SQLite)\nPRAGMA foreign_keys = ON;\n\n");
        for (String d : DDL) sb.append(d).append(";\n\n");
        Files.writeString(Paths.get("schema.sql"), sb.toString());
    }

    /** Prints a query result as a text table. */
    static void dump(Connection c, String sql, String title) throws SQLException {
        System.out.println("=== " + title + " ===");
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            ResultSetMetaData md = rs.getMetaData(); int n = md.getColumnCount();
            List<String[]> rows = new ArrayList<>(); int[] w = new int[n];
            String[] head = new String[n];
            for (int i = 0; i < n; i++) { head[i] = md.getColumnLabel(i + 1); w[i] = head[i].length(); }
            while (rs.next()) {
                String[] row = new String[n];
                for (int i = 0; i < n; i++) { String v = rs.getString(i + 1); if (v == null) v = "NULL"; if (v.length() > 32) v = v.substring(0, 29) + "..."; row[i] = v; w[i] = Math.max(w[i], v.length()); }
                rows.add(row);
            }
            printRow(head, w); StringBuilder sep = new StringBuilder();
            for (int x : w) sep.append("-".repeat(x)).append("-+-"); System.out.println(sep);
            for (String[] r : rows) printRow(r, w);
            System.out.println("(" + rows.size() + " rows)\n");
        }
    }
    static void printRow(String[] r, int[] w) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < r.length; i++) sb.append(String.format("%-" + w[i] + "s | ", r[i]));
        System.out.println(sb);
    }
}
