#!/bin/sh
cd "$(dirname "$0")"
mkdir -p out
javac -cp "lib/*" -d out CreateDatabase.java InternSphere.java
java -cp "out:lib/*" CreateDatabase
