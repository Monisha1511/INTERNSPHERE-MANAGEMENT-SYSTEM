-- Intern Sphere database schema (SQLite)
PRAGMA foreign_keys = ON;

CREATE TABLE users (
  id         INTEGER PRIMARY KEY,
  email      TEXT NOT NULL UNIQUE,
  password   TEXT NOT NULL,
  name       TEXT NOT NULL,
  role       TEXT NOT NULL CHECK (role IN ('manager','mentor','student')),
  mentor_id  INTEGER REFERENCES users(id)   -- only students have a mentor
);

CREATE TABLE reports (
  id          INTEGER PRIMARY KEY,
  student_id  INTEGER NOT NULL REFERENCES users(id),
  mentor_id   INTEGER NOT NULL REFERENCES users(id),
  project     TEXT NOT NULL,
  title       TEXT NOT NULL,
  assigned    TEXT NOT NULL,   -- yyyy-MM-dd
  deadline    TEXT NOT NULL,
  submitted   TEXT,            -- NULL until the student submits
  status      TEXT NOT NULL DEFAULT 'Pending'
              CHECK (status IN ('Pending','Pending Review','Approved','Have to Improve')),
  feedback    TEXT,            -- mentor feedback when status = 'Have to Improve'
  file_name   TEXT             -- submitted PDF / document
);

CREATE TABLE report_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  report_id  INTEGER NOT NULL REFERENCES reports(id),
  event_date TEXT NOT NULL,
  event      TEXT NOT NULL
);

CREATE TABLE notifications (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id),
  created    TEXT NOT NULL,
  message    TEXT NOT NULL,
  is_read    INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX idx_reports_student ON reports(student_id);

CREATE INDEX idx_reports_mentor_status ON reports(mentor_id, status);

CREATE VIEW pending_review_queue AS
  SELECT r.id, s.name AS student, m.name AS mentor, r.project, r.title, r.submitted, r.file_name
  FROM reports r JOIN users s ON s.id = r.student_id JOIN users m ON m.id = r.mentor_id
  WHERE r.status = 'Pending Review';

