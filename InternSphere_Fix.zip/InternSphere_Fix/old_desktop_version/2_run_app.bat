@echo off
cd /d "%~dp0"
if not exist out mkdir out
javac -cp "lib/*" -d out InternSphere.java
java -cp "out;lib/*" InternSphere
pause
