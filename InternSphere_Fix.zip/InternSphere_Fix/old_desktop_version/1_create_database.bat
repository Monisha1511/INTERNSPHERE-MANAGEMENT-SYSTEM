@echo off
cd /d "%~dp0"
if not exist out mkdir out
javac -cp "lib/*" -d out CreateDatabase.java InternSphere.java
java -cp "out;lib/*" CreateDatabase
pause
