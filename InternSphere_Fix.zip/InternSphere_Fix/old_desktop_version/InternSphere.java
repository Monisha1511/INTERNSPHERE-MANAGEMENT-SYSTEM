import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;
import java.util.function.*;
import java.util.stream.*;

/**
 * Intern Sphere - Java Swing desktop demo (single file, no external libraries).
 * Needs the SQLite JDBC driver jar (sqlite-jdbc-3.46.1.3.jar) next to this file.
 * Compile:  javac InternSphere.java
 * Run:      java -cp ".:sqlite-jdbc-3.46.1.3.jar" InternSphere      (Windows: use ; instead of :)
 * Database (internsphere.db), session and report PDFs are stored in  <home>/.internsphere/
 */
public class InternSphere {
    // ---------- model ----------
    static class User implements Serializable {
        int id, mentorId; String email, pwd, name, role;
        User(int id, String email, String pwd, String name, String role, int mentorId) {
            this.id = id; this.email = email; this.pwd = pwd; this.name = name; this.role = role; this.mentorId = mentorId;
        }
        public String toString() { return name; }
    }
    static class Report implements Serializable {
        int id, studentId, mentorId;
        String student, project, title, assigned, deadline, submitted = "", status = "Pending", feedback = "", fileName = "", filePath = "";
        List<String> log = new ArrayList<>();
    }
    static class Data implements Serializable {
        List<User> users = new ArrayList<>(); List<Report> reports = new ArrayList<>(); Map<Integer, List<String>> notifs = new HashMap<>();
    }

    static final String PENDING = "Pending", REVIEW = "Pending Review", APPROVED = "Approved", IMPROVE = "Have to Improve";
    static final Color INK = new Color(0x17211d), ACC = new Color(0xe49b35), BG = new Color(0xf3f0e8), TEAL = new Color(0x0f766e);
    static final Path DIR = Paths.get(System.getProperty("user.home"), ".internsphere"), FILES = DIR.resolve("files"),
            DBFILE = DIR.resolve("internsphere.db"), SESSION = DIR.resolve("session.txt");
    static final DateTimeFormatter DF = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH);
    static Data D; static Connection C; static JFrame F; static User CUR;
    static final List<Runnable> refreshers = new ArrayList<>();

    // ---------- persistence ----------
    static String fmt(String iso) { return LocalDate.parse(iso).format(DF); }
    /** SQLite database: users, reports, report_log, notifications (file: <home>/.internsphere/internsphere.db) */
    static void save() {
        try {
            C.setAutoCommit(false);
            try (Statement st = C.createStatement()) { for (String t : new String[]{"notifications", "report_log", "reports", "users"}) st.executeUpdate("DELETE FROM " + t); }
            try (PreparedStatement u = C.prepareStatement("INSERT INTO users VALUES(?,?,?,?,?,?)")) {
                for (User x : D.users) { u.setInt(1, x.id); u.setString(2, x.email); u.setString(3, x.pwd); u.setString(4, x.name); u.setString(5, x.role); u.setInt(6, x.mentorId); u.executeUpdate(); } }
            try (PreparedStatement r = C.prepareStatement("INSERT INTO reports VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");
                 PreparedStatement l = C.prepareStatement("INSERT INTO report_log(report_id,seq,entry) VALUES(?,?,?)")) {
                for (Report x : D.reports) {
                    Object[] v = {x.id, x.studentId, x.mentorId, x.student, x.project, x.title, x.assigned, x.deadline, x.submitted, x.status, x.feedback, x.fileName, x.filePath};
                    for (int i = 0; i < v.length; i++) r.setObject(i + 1, v[i]);
                    r.executeUpdate();
                    for (int i = 0; i < x.log.size(); i++) { l.setInt(1, x.id); l.setInt(2, i); l.setString(3, x.log.get(i)); l.executeUpdate(); }
                } }
            try (PreparedStatement n = C.prepareStatement("INSERT INTO notifications(user_id,seq,message) VALUES(?,?,?)")) {
                for (Map.Entry<Integer, List<String>> e : D.notifs.entrySet())
                    for (int i = 0; i < e.getValue().size(); i++) { n.setInt(1, e.getKey()); n.setInt(2, i); n.setString(3, e.getValue().get(i)); n.executeUpdate(); } }
            C.commit(); C.setAutoCommit(true);
        } catch (SQLException e) { e.printStackTrace(); try { C.rollback(); C.setAutoCommit(true); } catch (SQLException x) { } }
    }
    static void load() {
        try {
            Files.createDirectories(FILES);
            C = DriverManager.getConnection("jdbc:sqlite:" + DBFILE);
            try (Statement st = C.createStatement()) {
                st.executeUpdate("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE, password TEXT, name TEXT, role TEXT, mentor_id INTEGER)");
                st.executeUpdate("CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY, student_id INTEGER REFERENCES users(id), mentor_id INTEGER REFERENCES users(id), student TEXT, project TEXT, title TEXT, assigned TEXT, deadline TEXT, submitted TEXT, status TEXT, feedback TEXT, file_name TEXT, file_path TEXT)");
                st.executeUpdate("CREATE TABLE IF NOT EXISTS report_log(id INTEGER PRIMARY KEY AUTOINCREMENT, report_id INTEGER REFERENCES reports(id), seq INTEGER, entry TEXT)");
                st.executeUpdate("CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER REFERENCES users(id), seq INTEGER, message TEXT)");
                D = new Data();
                try (ResultSet rs = st.executeQuery("SELECT * FROM users ORDER BY id")) {
                    while (rs.next()) D.users.add(new User(rs.getInt("id"), rs.getString("email"), rs.getString("password"), rs.getString("name"), rs.getString("role"), rs.getInt("mentor_id"))); }
                if (D.users.isEmpty()) { seed(); save(); return; }
                try (ResultSet rs = st.executeQuery("SELECT * FROM reports ORDER BY id")) {
                    while (rs.next()) { Report r = new Report(); r.id = rs.getInt("id"); r.studentId = rs.getInt("student_id"); r.mentorId = rs.getInt("mentor_id");
                        r.student = rs.getString("student"); r.project = rs.getString("project"); r.title = rs.getString("title"); r.assigned = rs.getString("assigned");
                        r.deadline = rs.getString("deadline"); r.submitted = rs.getString("submitted"); r.status = rs.getString("status"); r.feedback = rs.getString("feedback");
                        r.fileName = rs.getString("file_name"); r.filePath = rs.getString("file_path"); D.reports.add(r); } }
                Map<Integer, Report> by = D.reports.stream().collect(Collectors.toMap(r -> r.id, r -> r));
                try (ResultSet rs = st.executeQuery("SELECT * FROM report_log ORDER BY report_id, seq")) { while (rs.next()) by.get(rs.getInt("report_id")).log.add(rs.getString("entry")); }
                try (ResultSet rs = st.executeQuery("SELECT * FROM notifications ORDER BY user_id, seq")) {
                    while (rs.next()) D.notifs.computeIfAbsent(rs.getInt("user_id"), k -> new ArrayList<>()).add(rs.getString("message")); }
            }
        } catch (Exception e) { e.printStackTrace(); JOptionPane.showMessageDialog(null, "Database error (is sqlite-jdbc on the classpath?): " + e); System.exit(1); }
    }
    static User user(int id) { return D.users.stream().filter(u -> u.id == id).findFirst().orElse(null); }
    static void note(int uid, String msg) {
        D.notifs.computeIfAbsent(uid, k -> new ArrayList<>()).add(0, LocalDate.now().format(DF) + " - " + msg); save();
    }
    static void logR(Report r, String t) { r.log.add(LocalDate.now().format(DF) + " - " + t); }

    // ---------- real PDF generation ----------
    static String esc(String s) {
        return s.replaceAll("[^\\x20-\\x7E]", "?").replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)");
    }
    static void pdf(Path p, String title, List<String> lines) throws IOException {
        StringBuilder c = new StringBuilder("0.06 0.46 0.43 rg 0 770 612 22 re f 0.89 0.61 0.21 rg 0 766 612 4 re f\n"
                + "BT /F2 10 Tf 1 1 1 rg 50 776 Td (INTERN SPHERE  |  Project Report) Tj ET\n0.09 0.13 0.11 rg\n"
                + "BT /F2 18 Tf 50 735 Td (" + esc(title) + ") Tj ET\n");
        int y = 700;
        for (String l : lines) { c.append("BT /F1 11 Tf 50 ").append(y).append(" Td (").append(esc(l)).append(") Tj ET\n"); y -= 16; }
        String[] o = { "<< /Type /Catalog /Pages 2 0 R >>", "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
                "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>",
                "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>", "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>",
                "<< /Length " + c.length() + " >>\nstream\n" + c + "endstream" };
        StringBuilder s = new StringBuilder("%PDF-1.4\n"); int[] off = new int[o.length];
        for (int i = 0; i < o.length; i++) { off[i] = s.length(); s.append(i + 1).append(" 0 obj\n").append(o[i]).append("\nendobj\n"); }
        int x = s.length();
        s.append("xref\n0 ").append(o.length + 1).append("\n0000000000 65535 f \n");
        for (int f : off) s.append(String.format("%010d 00000 n \n", f));
        s.append("trailer\n<< /Size ").append(o.length + 1).append(" /Root 1 0 R >>\nstartxref\n").append(x).append("\n%%EOF");
        Files.write(p, s.toString().getBytes(StandardCharsets.ISO_8859_1));
    }
    static void makeReportFile(Report r, String status, String suffix) throws IOException {
        r.fileName = (r.student + "_" + r.title).replaceAll("\\s+", "_") + suffix + ".pdf";
        Path p = FILES.resolve(r.id + "_" + r.fileName);
        pdf(p, r.project + " - " + r.title, List.of("Student: " + r.student, "Project: " + r.project, "Report: " + r.title,
                "Mentor: " + user(r.mentorId).name, "Submitted: " + (r.submitted.isEmpty() ? "-" : fmt(r.submitted)), "Status: " + status, "",
                "Summary", "This report describes the progress made on the project for this internship milestone.", "",
                "Work completed", "- Built the core screens and data model", "- Tested the main user flow",
                "- Documented the results for mentor review", "", "Next steps", "- Address mentor feedback", "- Prepare the next milestone"));
        r.filePath = p.toString();
    }

    // ---------- seed data ----------
    static void seed() {
        D.users.addAll(List.of(
                new User(1, "manager@internsphere.com", "manager123", "Manager", "manager", 0),
                new User(2, "priya@intern.com", "mentor123", "Priya Mentor", "mentor", 0),
                new User(9, "ravi@intern.com", "mentor123", "Ravi Mentor", "mentor", 0),
                new User(3, "arun@intern.com", "student123", "Arun Student", "student", 2),
                new User(4, "bharathi@intern.com", "student123", "Bharathi S", "student", 2),
                new User(5, "charu@intern.com", "student123", "Charulatha K", "student", 2),
                new User(6, "dinesh@intern.com", "student123", "Dinesh R", "student", 9),
                new User(7, "ezhil@intern.com", "student123", "Ezhil V", "student", 9),
                new User(8, "fathima@intern.com", "student123", "Fathima B", "student", 9)));
        Map<Integer, String> proj = Map.of(3, "Smart Notes Organizer", 4, "Student Skill Portfolio", 5, "Internship Task Tracker",
                6, "Attendance Tracker", 7, "Library Management System", 8, "Weather Dashboard");
        // studentId, title, assigned, deadline, submitted, status, feedback
        String[][] S = {
                {"3", "Week 1 Report", "2026-10-01", "2026-10-04", "2026-10-03", APPROVED, ""},
                {"3", "Mini Project", "2026-10-03", "2026-10-08", "2026-10-06", REVIEW, ""},
                {"3", "Final Project", "2026-10-06", "2026-10-12", "", PENDING, ""},
                {"4", "Research Summary", "2026-09-28", "2026-10-02", "2026-10-01", APPROVED, ""},
                {"4", "Week 1 Report", "2026-10-01", "2026-10-05", "2026-10-05", REVIEW, ""},
                {"4", "Mini Project", "2026-10-05", "2026-10-11", "", PENDING, ""},
                {"5", "UI Prototype", "2026-09-29", "2026-10-03", "2026-10-02", APPROVED, ""},
                {"5", "Week 1 Report", "2026-10-01", "2026-10-05", "2026-10-04", IMPROVE,
                        "Please improve the project documentation and add screenshots of the implementation."},
                {"5", "Final Project", "2026-10-04", "2026-10-10", "", PENDING, ""},
                {"6", "Week 1 Report", "2026-10-02", "2026-10-06", "2026-10-06", REVIEW, ""},
                {"6", "Mini Project", "2026-10-05", "2026-10-12", "", PENDING, ""},
                {"7", "Week 1 Report", "2026-10-01", "2026-10-05", "2026-10-04", APPROVED, ""},
                {"7", "Final Project", "2026-10-06", "2026-10-13", "", PENDING, ""},
                {"8", "Week 1 Report", "2026-10-02", "2026-10-06", "2026-10-06", IMPROVE, "Add a clear README and explain how the data is refreshed."},
                {"8", "Mini Project", "2026-10-04", "2026-10-11", "", PENDING, ""}};
        Arrays.sort(S, Comparator.comparing(a -> a[2]));
        int id = 0;
        for (String[] s : S) {
            User u = user(Integer.parseInt(s[0])); Report r = new Report();
            r.id = ++id; r.studentId = u.id; r.student = u.name; r.mentorId = u.mentorId; r.project = proj.get(u.id); r.title = s[1];
            r.assigned = s[2]; r.deadline = s[3]; r.submitted = s[4]; r.status = s[5]; r.feedback = s[6];
            r.log.add(fmt(s[2]) + " - Assigned by mentor");
            if (!s[4].isEmpty()) {
                try { makeReportFile(r, s[5], ""); } catch (IOException e) { e.printStackTrace(); }
                r.log.add(fmt(s[4]) + " - Submitted " + r.fileName);
                if (s[5].equals(APPROVED)) r.log.add(fmt(s[4]) + " - Approved by mentor");
                if (s[5].equals(IMPROVE)) r.log.add(fmt(s[4]) + " - Returned: " + s[6]);
            }
            D.reports.add(r);
        }
    }

    // ---------- file actions ----------
    static void viewFile(Report r) {
        if (r.filePath.isEmpty()) { JOptionPane.showMessageDialog(F, "No file submitted for this report yet."); return; }
        try { Desktop.getDesktop().open(new File(r.filePath)); }
        catch (Exception e) { JOptionPane.showMessageDialog(F, "Could not open file: " + e.getMessage()); }
    }
    static void downloadFile(Report r) {
        if (r.filePath.isEmpty()) { JOptionPane.showMessageDialog(F, "No file submitted for this report yet."); return; }
        JFileChooser fc = new JFileChooser(); fc.setSelectedFile(new File(r.fileName));
        if (fc.showSaveDialog(F) != JFileChooser.APPROVE_OPTION) return;
        try { Files.copy(Paths.get(r.filePath), fc.getSelectedFile().toPath(), StandardCopyOption.REPLACE_EXISTING);
            JOptionPane.showMessageDialog(F, "Saved to " + fc.getSelectedFile()); }
        catch (IOException e) { JOptionPane.showMessageDialog(F, "Download failed: " + e.getMessage()); }
    }

    // ---------- workflow ----------
    static void refreshAll() { refreshers.forEach(Runnable::run); }
    static void approve(Report r) {
        if (!r.status.equals(REVIEW)) { JOptionPane.showMessageDialog(F, "Only reports in Pending Review can be approved."); return; }
        r.status = APPROVED; logR(r, "Approved by mentor");
        note(r.studentId, "Your report '" + r.title + "' (" + r.project + ") was approved."); save(); refreshAll();
    }
    static void improve(Report r) {
        if (!r.status.equals(REVIEW)) { JOptionPane.showMessageDialog(F, "Only reports in Pending Review can be returned."); return; }
        JTextArea ta = new JTextArea(5, 36); ta.setLineWrap(true); ta.setWrapStyleWord(true);
        if (JOptionPane.showConfirmDialog(F, new JScrollPane(ta), "Feedback for " + r.student, JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;
        String fb = ta.getText().trim();
        if (fb.isEmpty()) { JOptionPane.showMessageDialog(F, "Please type feedback before returning the report."); return; }
        r.status = IMPROVE; r.feedback = fb; logR(r, "Returned: Have to Improve - " + fb);
        note(r.studentId, "'" + r.title + "' needs improvement: " + fb + " Please resubmit."); save(); refreshAll();
    }
    static boolean canSubmit(Report r) {
        if (r.studentId != CUR.id || !(r.status.equals(PENDING) || r.status.equals(IMPROVE))) {
            JOptionPane.showMessageDialog(F, "This report is not open for submission."); return false; }
        return true;
    }
    static void finishSubmit(Report r, boolean resubmit) {
        r.status = REVIEW; r.submitted = LocalDate.now().toString(); logR(r, (resubmit ? "Resubmitted " : "Submitted ") + r.fileName);
        note(r.mentorId, r.student + (resubmit ? " resubmitted '" : " submitted '") + r.title + "' (" + r.project + "). Ready for review.");
        save(); refreshAll();
    }
    static void submitFile(Report r) {
        if (!canSubmit(r)) return;
        JFileChooser fc = new JFileChooser(); if (fc.showOpenDialog(F) != JFileChooser.APPROVE_OPTION) return;
        try {
            boolean re = r.status.equals(IMPROVE); File f = fc.getSelectedFile();
            Path dest = FILES.resolve(r.id + "_" + System.currentTimeMillis() + "_" + f.getName());
            Files.copy(f.toPath(), dest, StandardCopyOption.REPLACE_EXISTING);
            r.fileName = f.getName(); r.filePath = dest.toString(); finishSubmit(r, re);
        } catch (IOException e) { JOptionPane.showMessageDialog(F, "Could not attach file: " + e.getMessage()); }
    }
    static void submitDemo(Report r) {
        if (!canSubmit(r)) return;
        try {
            boolean re = r.status.equals(IMPROVE); r.submitted = LocalDate.now().toString();
            makeReportFile(r, REVIEW, "_Demo"); finishSubmit(r, re);
        } catch (IOException e) { JOptionPane.showMessageDialog(F, "Could not create demo file: " + e.getMessage()); }
    }

    // ---------- UI components ----------
    /** A refreshable report table with built-in View / Download plus custom action buttons. */
    static class RP extends JPanel {
        final Supplier<List<Report>> src; List<Report> cur = new ArrayList<>(); final DefaultTableModel m; final JTable t;
        RP(Supplier<List<Report>> src, Map<String, Consumer<Report>> actions) {
            super(new BorderLayout(0, 6)); this.src = src; setBackground(BG);
            m = new DefaultTableModel(new String[]{"Student", "Project", "Report", "Assigned", "Deadline", "Submitted", "Status", "File", "Feedback"}, 0) {
                public boolean isCellEditable(int r, int c) { return false; } };
            t = new JTable(m); t.setRowHeight(24); t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            t.getColumnModel().getColumn(6).setCellRenderer(new DefaultTableCellRenderer() {
                public Component getTableCellRendererComponent(JTable tb, Object v, boolean sel, boolean foc, int r, int c) {
                    Component x = super.getTableCellRendererComponent(tb, v, sel, foc, r, c); String s = String.valueOf(v);
                    if (!sel) x.setForeground(s.equals(APPROVED) ? new Color(0x287d55) : s.equals(IMPROVE) ? new Color(0xb94a48) : s.equals(REVIEW) ? TEAL : new Color(0xb46b18));
                    return x; } });
            add(new JScrollPane(t), BorderLayout.CENTER);
            JPanel b = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0)); b.setOpaque(false);
            b.add(btn("View", () -> sel(InternSphere::viewFile))); b.add(btn("Download", () -> sel(InternSphere::downloadFile)));
            actions.forEach((n, a) -> b.add(btn(n, () -> sel(a)))); add(b, BorderLayout.SOUTH);
            refreshers.add(this::refresh); refresh();
        }
        void sel(Consumer<Report> a) { int i = t.getSelectedRow(); if (i < 0) { JOptionPane.showMessageDialog(F, "Select a row first."); return; } a.accept(cur.get(i)); }
        void refresh() {
            cur = src.get(); m.setRowCount(0);
            for (Report r : cur) m.addRow(new Object[]{r.student, r.project, r.title, fmt(r.assigned), fmt(r.deadline),
                    r.submitted.isEmpty() ? "--" : fmt(r.submitted), r.status, r.fileName.isEmpty() ? "--" : r.fileName, r.feedback});
        }
    }
    static JButton btn(String t, Runnable r) { JButton b = new JButton(t); b.addActionListener(e -> r.run()); return b; }
    static List<Report> reportsWhere(Predicate<Report> p, boolean newestFirst) {
        return D.reports.stream().filter(p).sorted(newestFirst ? Comparator.comparingInt((Report r) -> r.id).reversed()
                : Comparator.comparingInt((Report r) -> r.id)).collect(Collectors.toList());
    }
    static JPanel notifPanel(User u) {
        DefaultListModel<String> lm = new DefaultListModel<>(); JPanel p = new JPanel(new BorderLayout());
        p.add(new JScrollPane(new JList<>(lm)));
        Runnable r = () -> { lm.clear(); D.notifs.getOrDefault(u.id, List.of()).forEach(lm::addElement); }; r.run(); refreshers.add(r); return p;
    }
    static JPanel pad(JComponent c) { JPanel p = new JPanel(new BorderLayout()); p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); p.setBackground(BG); p.add(c); return p; }

    static JComponent assignTab(User u, List<User> students) {
        JTextField proj = new JTextField(22), title = new JTextField(22), dl = new JTextField(LocalDate.now().plusDays(7).toString(), 22);
        JComboBox<Object> who = new JComboBox<>(); who.addItem("All my students"); students.forEach(who::addItem);
        JPanel f = new JPanel(new GridLayout(0, 2, 8, 8)); f.setOpaque(false);
        f.add(new JLabel("Project")); f.add(proj); f.add(new JLabel("Report title")); f.add(title);
        f.add(new JLabel("Student")); f.add(who); f.add(new JLabel("Deadline (yyyy-MM-dd)")); f.add(dl);
        f.add(new JLabel()); f.add(btn("Assign", () -> {
            try {
                String d = LocalDate.parse(dl.getText().trim()).toString(); String t = title.getText().trim();
                if (t.isEmpty()) { JOptionPane.showMessageDialog(F, "Enter a report title."); return; }
                int next = D.reports.stream().mapToInt(r -> r.id).max().orElse(0);
                for (User s : students) {
                    if (who.getSelectedItem() instanceof User && who.getSelectedItem() != s) continue;
                    Report r = new Report(); r.id = ++next; r.studentId = s.id; r.student = s.name; r.mentorId = u.id;
                    r.project = proj.getText().trim().isEmpty() ? t : proj.getText().trim(); r.title = t;
                    r.assigned = LocalDate.now().toString(); r.deadline = d; logR(r, "Assigned by mentor"); D.reports.add(r);
                    note(s.id, "New project assigned: '" + t + "'. Deadline: " + fmt(d));
                }
                save(); refreshAll(); JOptionPane.showMessageDialog(F, "Assigned. Students notified.");
            } catch (Exception e) { JOptionPane.showMessageDialog(F, "Invalid deadline. Use yyyy-MM-dd."); }
        }));
        JPanel w = new JPanel(new FlowLayout(FlowLayout.LEFT)); w.setOpaque(false); w.add(f); return pad(w);
    }

    /** Manager "Database" tab: browse tables and run read-only SELECT queries against the live SQLite DB. */
    static JComponent dbTab() {
        JComboBox<String> tb = new JComboBox<>(new String[]{"users", "reports", "report_log", "notifications"});
        JTextField sql = new JTextField("SELECT * FROM reports"); JLabel info = new JLabel(" Database file: " + DBFILE);
        DefaultTableModel m = new DefaultTableModel() { public boolean isCellEditable(int r, int c) { return false; } }; JTable t = new JTable(m); t.setRowHeight(22);
        Runnable run = () -> {
            String q = sql.getText().trim();
            if (!q.toLowerCase().startsWith("select")) { info.setText(" Only SELECT queries are allowed here."); return; }
            try (Statement st = C.createStatement(); ResultSet rs = st.executeQuery(q)) {
                ResultSetMetaData md = rs.getMetaData(); int n = md.getColumnCount(); String[] cols = new String[n];
                for (int i = 0; i < n; i++) cols[i] = md.getColumnLabel(i + 1);
                m.setColumnIdentifiers(cols); m.setRowCount(0);
                while (rs.next()) { Object[] row = new Object[n]; for (int i = 0; i < n; i++) row[i] = rs.getObject(i + 1); m.addRow(row); }
                info.setText(" " + m.getRowCount() + " row(s)  |  Database file: " + DBFILE);
            } catch (SQLException e) { info.setText(" SQL error: " + e.getMessage()); }
        };
        tb.addActionListener(e -> { sql.setText("SELECT * FROM " + tb.getSelectedItem()); run.run(); });
        sql.addActionListener(e -> run.run()); refreshers.add(run); run.run();
        JPanel top = new JPanel(new BorderLayout(6, 0)); top.setOpaque(false);
        JPanel l = new JPanel(new FlowLayout(FlowLayout.LEFT)); l.setOpaque(false); l.add(new JLabel("Table:")); l.add(tb);
        top.add(l, BorderLayout.WEST); top.add(sql); top.add(btn("Run SQL", run), BorderLayout.EAST);
        JPanel p = new JPanel(new BorderLayout(0, 6)); p.setOpaque(false); p.add(top, BorderLayout.NORTH); p.add(new JScrollPane(t)); p.add(info, BorderLayout.SOUTH);
        return pad(p);
    }

    static void showDash(User u) {
        CUR = u; refreshers.clear();
        JTabbedPane tabs = new JTabbedPane();
        if (u.role.equals("manager")) {
            tabs.addTab("All Project / Report Files", pad(new RP(() -> reportsWhere(r -> !r.filePath.isEmpty(), true), new LinkedHashMap<>())));
            tabs.addTab("Database", dbTab());
        } else if (u.role.equals("mentor")) {
            List<User> students = D.users.stream().filter(s -> s.role.equals("student") && s.mentorId == u.id).collect(Collectors.toList());
            JList<User> list = new JList<>(students.toArray(new User[0])); list.setSelectedIndex(students.isEmpty() ? -1 : 0);
            RP hist = new RP(() -> { User s = list.getSelectedValue();
                return s == null ? new ArrayList<>() : reportsWhere(r -> r.studentId == s.id && r.mentorId == u.id, false); }, new LinkedHashMap<>());
            list.addListSelectionListener(e -> hist.refresh());
            JScrollPane ls = new JScrollPane(list); ls.setBorder(BorderFactory.createTitledBorder("My Students (click one)")); ls.setPreferredSize(new Dimension(190, 0));
            JPanel hp = new JPanel(new BorderLayout(8, 0)); hp.setBackground(BG); hp.add(ls, BorderLayout.WEST);
            hp.add(hist, BorderLayout.CENTER); hist.setBorder(BorderFactory.createTitledBorder("Report History"));
            tabs.addTab("My Students", pad(hp));
            tabs.addTab("Recently Assigned Projects", pad(new RP(() -> reportsWhere(r -> r.mentorId == u.id, true), new LinkedHashMap<>())));
            Map<String, Consumer<Report>> rv = new LinkedHashMap<>(); rv.put("Approve", InternSphere::approve); rv.put("Have to Improve", InternSphere::improve);
            tabs.addTab("Pending Review", pad(new RP(() -> reportsWhere(r -> r.mentorId == u.id && r.status.equals(REVIEW), true), rv)));
            tabs.addTab("Assign Project", assignTab(u, students));
        } else {
            Map<String, Consumer<Report>> sa = new LinkedHashMap<>(); sa.put("Attach & Submit / Resubmit", InternSphere::submitFile); sa.put("Submit Demo File", InternSphere::submitDemo);
            tabs.addTab("My Reports", pad(new RP(() -> reportsWhere(r -> r.studentId == u.id, true), sa)));
        }
        tabs.addTab("Notifications", notifPanel(u));
        JPanel top = new JPanel(new BorderLayout()); top.setBackground(INK); top.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, ACC));
        JLabel l = new JLabel("  Intern Sphere   |   " + u.role.toUpperCase() + "   |   " + u.name); l.setForeground(Color.WHITE);
        l.setFont(l.getFont().deriveFont(Font.BOLD, 14f));
        top.add(l, BorderLayout.WEST);
        top.add(btn("Sign Out", () -> { try { Files.deleteIfExists(SESSION); } catch (IOException e) { } CUR = null; showLogin(); }), BorderLayout.EAST);
        JPanel root = new JPanel(new BorderLayout()); root.add(top, BorderLayout.NORTH); root.add(tabs);
        F.setContentPane(root); F.revalidate(); F.repaint();
    }

    static void showLogin() {
        JTextField email = new JTextField(20); JPasswordField pwd = new JPasswordField(20); JCheckBox rem = new JCheckBox("Remember me");
        JPanel card = new JPanel(new GridLayout(0, 1, 6, 6)); card.setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));
        JLabel h = new JLabel("Intern Sphere"); h.setFont(h.getFont().deriveFont(Font.BOLD, 26f)); card.add(h);
        card.add(new JLabel("Email")); card.add(email); card.add(new JLabel("Password")); card.add(pwd); card.add(rem);
        Runnable go = () -> {
            User u = D.users.stream().filter(x -> x.email.equalsIgnoreCase(email.getText().trim()) && x.pwd.equals(new String(pwd.getPassword()))).findFirst().orElse(null);
            if (u == null) { JOptionPane.showMessageDialog(F, "Invalid email or password"); return; }
            try { if (rem.isSelected()) Files.writeString(SESSION, u.email); else Files.deleteIfExists(SESSION); } catch (IOException e) { }
            showDash(u);
        };
        card.add(btn("Sign In", go)); pwd.addActionListener(e -> go.run());
        JLabel hint = new JLabel("<html><small>Demo: manager@internsphere.com / manager123<br>priya@intern.com, ravi@intern.com / mentor123<br>arun@intern.com, charu@intern.com ... / student123</small></html>");
        card.add(hint);
        JPanel root = new JPanel(new GridBagLayout()); root.setBackground(BG); root.add(card);
        F.setContentPane(root); F.revalidate(); F.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            load();
            F = new JFrame("Intern Sphere - Internship Management"); F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); F.setSize(1100, 640); F.setLocationRelativeTo(null);
            showLogin();
            try { // Remember Me: restore the last saved login
                if (Files.exists(SESSION)) { String em = Files.readString(SESSION).trim();
                    D.users.stream().filter(u -> u.email.equalsIgnoreCase(em)).findFirst().ifPresent(InternSphere::showDash); }
            } catch (IOException e) { }
            F.setVisible(true);
        });
    }
}
