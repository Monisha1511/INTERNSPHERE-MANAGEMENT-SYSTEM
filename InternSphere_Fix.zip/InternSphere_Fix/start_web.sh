#!/bin/sh
cd "$(dirname "$0")"
mkdir -p out
javac -cp "lib/*" -d out InternSphereServer.java
java -cp "out:lib/*" InternSphereServer
