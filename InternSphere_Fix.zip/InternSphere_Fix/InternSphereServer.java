import com.sun.net.httpserver.*;
import java.awt.Desktop;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/**
 * Intern Sphere - web server (Java + SQLite, no frameworks).
 * Serves web/index.html in the browser and stores ALL data in intern_sphere_web.db.
 *
 *   GET  /              the Intern Sphere web interface
 *   GET  /api/state     loads everything from the SQLite tables
 *   POST /api/state     saves everything into the SQLite tables
 *   GET  /api/sql?q=    read-only SELECT queries (used by the manager's Database tab)
 *
 * Compile:  javac -cp "lib/*" -d out InternSphereServer.java
 * Run:      java -cp "out;lib/*" InternSphereServer      (Mac/Linux: use : instead of ;)
 * Then open http://localhost:8080
 */
public class InternSphereServer {
    static Connection C;

    // ---------- tiny JSON parser (the JDK has none) ----------
    static class J {
        final String s; int i;
        J(String s) { this.s = s; }
        void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
        Object parse() {
            ws(); char c = s.charAt(i);
            if (c == '{') {
                i++; Map<String, Object> m = new LinkedHashMap<>(); ws();
                if (s.charAt(i) == '}') { i++; return m; }
                while (true) { ws(); String k = str(); ws(); i++; m.put(k, parse()); ws(); if (s.charAt(i++) == '}') return m; }
            }
            if (c == '[') {
                i++; List<Object> l = new ArrayList<>(); ws();
                if (s.charAt(i) == ']') { i++; return l; }
                while (true) { l.add(parse()); ws(); if (s.charAt(i++) == ']') return l; }
            }
            if (c == '"') return str();
            if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
            if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
            if (s.startsWith("null", i)) { i += 4; return null; }
            int j = i; while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
            String n = s.substring(j, i);
            return n.matches("-?\\d+") ? (Object) Long.valueOf(n) : (Object) Double.valueOf(n);
        }
        String str() {
            i++; StringBuilder b = new StringBuilder();
            while (true) {
                char c = s.charAt(i++);
                if (c == '"') return b.toString();
                if (c == '\\') {
                    char e = s.charAt(i++);
                    switch (e) {
                        case 'n': b.append('\n'); break; case 't': b.append('\t'); break; case 'r': b.append('\r'); break;
                        case 'b': b.append('\b'); break; case 'f': b.append('\f'); break;
                        case 'u': b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; break;
                        default: b.append(e);
                    }
                } else b.append(c);
            }
        }
    }
    @SuppressWarnings("unchecked") static Map<String, Object> M(Object o) { return o instanceof Map ? (Map<String, Object>) o : new LinkedHashMap<>(); }
    @SuppressWarnings("unchecked") static List<Object> L(Object o) { return o instanceof List ? (List<Object>) o : new ArrayList<>(); }
    static Object bool(Object o) { return Boolean.TRUE.equals(o) ? 1 : 0; }
    static String q(Object o) {   // JSON value
        if (o == null) return "null"; if (o instanceof Number || o instanceof Boolean) return o.toString();
        StringBuilder b = new StringBuilder("\"");
        for (char c : o.toString().toCharArray()) {
            switch (c) {
                case '"': b.append("\\\""); break; case '\\': b.append("\\\\"); break; case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break; case '\t': b.append("\\t"); break;
                default: if (c < 0x20) b.append(String.format("\\u%04x", (int) c)); else b.append(c);
            }
        }
        return b.append('"').toString();
    }

    static String toJson(Object o) {
        if (o instanceof Map) { StringBuilder b = new StringBuilder("{"); boolean f = true;
            for (Map.Entry<?, ?> e : ((Map<?, ?>) o).entrySet()) { if (!f) b.append(','); f = false; b.append(q(e.getKey().toString())).append(':').append(toJson(e.getValue())); }
            return b.append('}').toString(); }
        if (o instanceof List) { StringBuilder b = new StringBuilder("["); boolean f = true;
            for (Object x : (List<?>) o) { if (!f) b.append(','); f = false; b.append(toJson(x)); }
            return b.append(']').toString(); }
        return q(o);
    }

    // ---------- database ----------
    static void createTables() throws SQLException {
        String[] ddl = {
            "CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE, password TEXT, name TEXT, role TEXT CHECK(role IN ('manager','mentor','student')), mentor_id INTEGER)",
            "CREATE TABLE IF NOT EXISTS mentors(id INTEGER PRIMARY KEY, name TEXT, email TEXT, deadline_date TEXT, deadline_status TEXT)",
            "CREATE TABLE IF NOT EXISTS mentor_students(mentor_id INTEGER, student_id INTEGER, student_name TEXT)",
            "CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY, student_id INTEGER, mentor_id INTEGER, student TEXT, project TEXT, title TEXT, description TEXT, requirements TEXT, "
                + "assigned_at TEXT, deadline TEXT, submitted TEXT, status TEXT CHECK(status IN ('pending','evaluated','unanalyzed')), feedback TEXT, file_name TEXT, file_type TEXT, file_size INTEGER, "
                + "file_demo INTEGER, reviewed_at TEXT, file_data TEXT, eval_json TEXT, match_score INTEGER, result TEXT)",
            "CREATE TABLE IF NOT EXISTS report_log(id INTEGER PRIMARY KEY AUTOINCREMENT, report_id INTEGER, seq INTEGER, at TEXT, txt TEXT)",
            "CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, seq INTEGER, message TEXT, is_read INTEGER, time TEXT)",
            "CREATE TABLE IF NOT EXISTS doubts(id INTEGER PRIMARY KEY, student_id INTEGER, mentor_id INTEGER, student TEXT, question TEXT, answer TEXT, time TEXT)",
            "CREATE TABLE IF NOT EXISTS pending_reasons(id INTEGER PRIMARY KEY, mentor TEXT, mentor_id INTEGER, deadline TEXT, reason TEXT)",
            "CREATE TABLE IF NOT EXISTS mentor_reports(id INTEGER PRIMARY KEY, mentor_id INTEGER, mentor TEXT, period_start TEXT, period_end TEXT, summary TEXT, remarks TEXT, submitted_at TEXT, status TEXT)",
            "CREATE TABLE IF NOT EXISTS risk_alerts(id INTEGER PRIMARY KEY, type TEXT, severity TEXT, mentor_id INTEGER, student_id INTEGER, message TEXT, created_at TEXT, resolved INTEGER)",
            "CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT)"};
        try (Statement st = C.createStatement()) {
            boolean hasEval = false;   // older database (manual review version): rebuild report tables, the page re-creates the demo data
            try (ResultSet rs = st.executeQuery("PRAGMA table_info(reports)")) { while (rs.next()) if ("eval_json".equals(rs.getString("name"))) hasEval = true; }
            if (!hasEval) for (String t : new String[]{"reports", "report_log", "meta"}) st.executeUpdate("DROP TABLE IF EXISTS " + t);
            for (String d : ddl) st.executeUpdate(d);
        }
    }
    static void insert(String sql, Object... v) throws SQLException {
        try (PreparedStatement p = C.prepareStatement(sql)) { for (int i = 0; i < v.length; i++) p.setObject(i + 1, v[i]); p.executeUpdate(); }
    }

    // Show a Windows toast for every newly saved notification, regardless of the
    // recipient's InternSphere login. The toast belongs to this Windows laptop.
    static void showWindowsToast(String title, String message) {
        if (!System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win")) return;
        Path script = Paths.get(System.getProperty("user.dir"), "notify-toast.ps1").toAbsolutePath().normalize();
        Path log = Paths.get(System.getProperty("user.dir"), "notification-debug.log").toAbsolutePath();
        if (!Files.exists(script)) {
            logNotification(log, "ERROR: Toast helper not found: " + script);
            return;
        }
        try {
            Process p = new ProcessBuilder("powershell.exe", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass",
                    "-File", script.toString(), title, message).redirectErrorStream(true).start();
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            try (InputStream in = p.getInputStream()) { in.transferTo(output); }
            int exit = p.waitFor();
            String details = output.toString(StandardCharsets.UTF_8).trim();
            logNotification(log, "Toast exit=" + exit + " | " + message + (details.isEmpty() ? "" : " | " + details));
        } catch (Exception e) {
            logNotification(log, "ERROR showing toast: " + e);
        }
    }

    static synchronized void logNotification(Path log, String line) {
        try { Files.writeString(log, java.time.LocalDateTime.now() + " " + line + System.lineSeparator(),
                StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND); }
        catch (IOException ignored) { System.err.println(line); }
    }

    static synchronized void saveState(String body) throws Exception {
        Map<String, Object> root = M(new J(body).parse()), db = M(root.get("db"));
        // Count existing notifications rather than using a Set. A Set incorrectly
        // suppresses repeated identical notifications created in the same minute.
        Map<String, Integer> previousNotificationCounts = new HashMap<>();
        try (Statement st = C.createStatement(); ResultSet rs = st.executeQuery("SELECT user_id,message,time FROM notifications")) {
            while (rs.next()) {
                String key = rs.getLong(1) + "\\u0001" + rs.getString(2) + "\\u0001" + rs.getString(3);
                previousNotificationCounts.put(key, previousNotificationCounts.getOrDefault(key, 0) + 1);
            }
        }
        List<String> newNotifications = new ArrayList<>();
        Map<String, Integer> currentNotificationCounts = new HashMap<>();
        for (Map.Entry<String, Object> e : M(db.get("notifs")).entrySet()) {
            for (Object no : L(e.getValue())) {
                Map<String, Object> n = M(no);
                String message = String.valueOf(n.get("msg"));
                String time = String.valueOf(n.get("time"));
                String key = e.getKey() + "\\u0001" + message + "\\u0001" + time;
                int occurrence = currentNotificationCounts.getOrDefault(key, 0) + 1;
                currentNotificationCounts.put(key, occurrence);
                if (occurrence > previousNotificationCounts.getOrDefault(key, 0)) newNotifications.add(message);
            }
        }
        try {
            C.setAutoCommit(false);
            try (Statement st = C.createStatement()) {
                for (String t : new String[]{"users", "mentors", "mentor_students", "reports", "report_log", "notifications", "doubts", "pending_reasons", "mentor_reports", "risk_alerts", "meta"})
                    st.executeUpdate("DELETE FROM " + t);
            }
            for (Object o : L(root.get("users"))) { Map<String, Object> u = M(o);
                insert("INSERT INTO users VALUES(?,?,?,?,?,?)", u.get("id"), u.get("email"), u.get("pwd"), u.get("name"), u.get("role"), u.get("mentor_id")); }
            for (Object o : L(db.get("mentors"))) { Map<String, Object> m = M(o), d = M(m.get("deadline"));
                insert("INSERT INTO mentors VALUES(?,?,?,?,?)", m.get("id"), m.get("name"), m.get("email"), d.get("date"), d.get("status"));
                for (Object so : L(m.get("students"))) { Map<String, Object> s = M(so); insert("INSERT INTO mentor_students VALUES(?,?,?)", m.get("id"), s.get("id"), s.get("name")); } }
            for (Object o : L(db.get("reports"))) { Map<String, Object> r = M(o);
                Map<String, Object> ev = M(r.get("eval"));
                insert("INSERT INTO reports VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", r.get("id"), r.get("student_id"), r.get("mentor_id"), r.get("student"), r.get("project"), r.get("title"),
                    r.get("description"), toJson(r.get("requirements")), r.get("assigned_at"), r.get("deadline"), r.get("submitted"), r.get("status"), r.get("feedback"), r.get("fileName"), r.get("fileType"),
                    r.get("fileSize"), bool(r.get("fileDemo")), r.get("reviewed_at"), r.get("fileData"), r.get("eval") == null ? null : toJson(r.get("eval")), ev.get("score"), ev.get("result"));
                int seq = 0; for (Object lo : L(r.get("log"))) { Map<String, Object> l = M(lo); insert("INSERT INTO report_log(report_id,seq,at,txt) VALUES(?,?,?,?)", r.get("id"), seq++, l.get("at"), l.get("txt")); } }
            for (Map.Entry<String, Object> e : M(db.get("notifs")).entrySet()) { int seq = 0;
                for (Object no : L(e.getValue())) { Map<String, Object> n = M(no);
                    insert("INSERT INTO notifications(user_id,seq,message,is_read,time) VALUES(?,?,?,?,?)", Long.valueOf(e.getKey()), seq++, n.get("msg"), bool(n.get("read")), n.get("time")); } }
            for (Object o : L(db.get("doubts"))) { Map<String, Object> d = M(o);
                insert("INSERT INTO doubts VALUES(?,?,?,?,?,?,?)", d.get("id"), d.get("student_id"), d.get("mentor_id"), d.get("student"), d.get("q"), d.get("a"), d.get("time")); }
            for (Object o : L(db.get("pendingReasons"))) { Map<String, Object> p = M(o);
                insert("INSERT INTO pending_reasons VALUES(?,?,?,?,?)", p.get("id"), p.get("mentor"), p.get("mentor_id"), p.get("deadline"), p.get("reason")); }
            for (Object o : L(db.get("mentorReports"))) { Map<String, Object> r = M(o);
                insert("INSERT INTO mentor_reports VALUES(?,?,?,?,?,?,?,?,?)", r.get("id"), r.get("mentor_id"), r.get("mentor"), r.get("period_start"), r.get("period_end"), r.get("summary"), r.get("remarks"), r.get("submitted_at"), r.get("status")); }
            for (Object o : L(db.get("riskAlerts"))) { Map<String, Object> r = M(o);
                insert("INSERT INTO risk_alerts VALUES(?,?,?,?,?,?,?,?)", r.get("id"), r.get("type"), r.get("severity"), r.get("mentor_id"), r.get("student_id"), r.get("message"), r.get("created_at"), bool(r.get("resolved"))); }
            insert("INSERT INTO meta VALUES('seedVersion',?)", String.valueOf(db.get("seedVersion")));
            if (db.get("evalConfig") != null) insert("INSERT INTO meta VALUES('evalConfig',?)", toJson(db.get("evalConfig")));
            C.commit();
            // Show every newly added notification, including the first one after a clean start.
            // Existing notifications are excluded by the key comparison above, so this does not
            // replay the notification history or create duplicates on ordinary state saves.
            for (String message : newNotifications) showWindowsToast("InternSphere", message);
        } catch (Exception e) { C.rollback(); throw e; } finally { C.setAutoCommit(true); }
    }

    static synchronized String loadState() throws SQLException {
        try (Statement st = C.createStatement()) {
            try (ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM users")) { rs.next(); if (rs.getInt(1) == 0) return "{}"; }
            StringBuilder b = new StringBuilder("{\"users\":[");
            try (ResultSet rs = st.executeQuery("SELECT * FROM users ORDER BY rowid")) { boolean f = true;
                while (rs.next()) { if (!f) b.append(','); f = false;
                    b.append("{\"id\":").append(q(rs.getObject("id"))).append(",\"email\":").append(q(rs.getString("email"))).append(",\"pwd\":").append(q(rs.getString("password")))
                     .append(",\"name\":").append(q(rs.getString("name"))).append(",\"role\":").append(q(rs.getString("role"))).append(",\"mentor_id\":").append(q(rs.getObject("mentor_id"))).append('}'); } }
            b.append("],\"db\":{\"mentors\":[");
            try (ResultSet rs = st.executeQuery("SELECT * FROM mentors ORDER BY rowid")) { boolean f = true;
                while (rs.next()) { if (!f) b.append(','); f = false; long id = rs.getLong("id");
                    b.append("{\"id\":").append(id).append(",\"name\":").append(q(rs.getString("name"))).append(",\"email\":").append(q(rs.getString("email"))).append(",\"students\":[");
                    try (Statement s2 = C.createStatement(); ResultSet r2 = s2.executeQuery("SELECT * FROM mentor_students WHERE mentor_id=" + id + " ORDER BY rowid")) { boolean g = true;
                        while (r2.next()) { if (!g) b.append(','); g = false; b.append("{\"id\":").append(r2.getLong("student_id")).append(",\"name\":").append(q(r2.getString("student_name"))).append('}'); } }
                    b.append("],\"deadline\":");
                    if (rs.getString("deadline_date") == null) b.append("null"); else b.append("{\"date\":").append(q(rs.getString("deadline_date"))).append(",\"status\":").append(q(rs.getString("deadline_status"))).append('}');
                    b.append('}'); } }
            Map<Long, List<String>> logs = new HashMap<>();
            try (ResultSet rs = st.executeQuery("SELECT * FROM report_log ORDER BY report_id, seq")) {
                while (rs.next()) logs.computeIfAbsent(rs.getLong("report_id"), k -> new ArrayList<>()).add("{\"at\":" + q(rs.getString("at")) + ",\"txt\":" + q(rs.getString("txt")) + "}"); }
            b.append("],\"reports\":[");
            try (ResultSet rs = st.executeQuery("SELECT * FROM reports ORDER BY id")) { boolean f = true;
                while (rs.next()) { if (!f) b.append(','); f = false; long id = rs.getLong("id");
                    b.append("{\"id\":").append(id).append(",\"student_id\":").append(q(rs.getObject("student_id"))).append(",\"mentor_id\":").append(q(rs.getObject("mentor_id")))
                     .append(",\"student\":").append(q(rs.getString("student"))).append(",\"project\":").append(q(rs.getString("project"))).append(",\"title\":").append(q(rs.getString("title")))
                     .append(",\"description\":").append(q(rs.getString("description"))).append(",\"requirements\":").append(rs.getString("requirements") == null ? "[]" : rs.getString("requirements"))
                     .append(",\"eval\":").append(rs.getString("eval_json") == null ? "null" : rs.getString("eval_json"))
                     .append(",\"assigned_at\":").append(q(rs.getString("assigned_at"))).append(",\"deadline\":").append(q(rs.getString("deadline"))).append(",\"submitted\":").append(q(rs.getString("submitted")))
                     .append(",\"status\":").append(q(rs.getString("status"))).append(",\"feedback\":").append(q(rs.getString("feedback")))
                     .append(",\"fileName\":").append(q(rs.getString("file_name"))).append(",\"fileType\":").append(q(rs.getString("file_type"))).append(",\"fileSize\":").append(q(rs.getObject("file_size")))
                     .append(",\"fileDemo\":").append(rs.getInt("file_demo") == 1).append(",\"reviewed_at\":").append(q(rs.getString("reviewed_at"))).append(",\"fileData\":").append(q(rs.getString("file_data")))
                     .append(",\"log\":[").append(String.join(",", logs.getOrDefault(id, List.of()))).append("]}"); } }
            b.append("],\"doubts\":[");
            try (ResultSet rs = st.executeQuery("SELECT * FROM doubts ORDER BY rowid")) { boolean f = true;
                while (rs.next()) { if (!f) b.append(','); f = false;
                    b.append("{\"id\":").append(q(rs.getObject("id"))).append(",\"student_id\":").append(q(rs.getObject("student_id"))).append(",\"mentor_id\":").append(q(rs.getObject("mentor_id")))
                     .append(",\"student\":").append(q(rs.getString("student"))).append(",\"q\":").append(q(rs.getString("question"))).append(",\"a\":").append(q(rs.getString("answer")))
                     .append(",\"time\":").append(q(rs.getString("time"))).append('}'); } }
            b.append("],\"notifs\":{");
            Map<Long, List<String>> ns = new LinkedHashMap<>();
            try (ResultSet rs = st.executeQuery("SELECT * FROM notifications ORDER BY user_id, seq")) {
                while (rs.next()) ns.computeIfAbsent(rs.getLong("user_id"), k -> new ArrayList<>()).add("{\"msg\":" + q(rs.getString("message")) + ",\"read\":" + (rs.getInt("is_read") == 1) + ",\"time\":" + q(rs.getString("time")) + "}"); }
            b.append(String.join(",", ns.entrySet().stream().map(e -> "\"" + e.getKey() + "\":[" + String.join(",", e.getValue()) + "]").toArray(String[]::new)));
            b.append("},\"pendingReasons\":[");
            try (ResultSet rs = st.executeQuery("SELECT * FROM pending_reasons ORDER BY rowid")) { boolean f = true;
                while (rs.next()) { if (!f) b.append(','); f = false;
                    b.append("{\"id\":").append(q(rs.getObject("id"))).append(",\"mentor\":").append(q(rs.getString("mentor"))).append(",\"mentor_id\":").append(q(rs.getObject("mentor_id")))
                     .append(",\"deadline\":").append(q(rs.getString("deadline"))).append(",\"reason\":").append(q(rs.getString("reason"))).append('}'); } }
            b.append("],\"mentorReports\":[");
            try (ResultSet rs = st.executeQuery("SELECT * FROM mentor_reports ORDER BY id")) { boolean f = true;
                while (rs.next()) { if (!f) b.append(','); f = false;
                    b.append("{\"id\":").append(q(rs.getObject("id"))).append(",\"mentor_id\":").append(q(rs.getObject("mentor_id")))
                     .append(",\"mentor\":").append(q(rs.getString("mentor"))).append(",\"period_start\":").append(q(rs.getString("period_start")))
                     .append(",\"period_end\":").append(q(rs.getString("period_end"))).append(",\"summary\":").append(q(rs.getString("summary")))
                     .append(",\"remarks\":").append(q(rs.getString("remarks"))).append(",\"submitted_at\":").append(q(rs.getString("submitted_at")))
                     .append(",\"status\":").append(q(rs.getString("status"))).append('}'); } }
            b.append("],\"riskAlerts\":[");
            try (ResultSet rs = st.executeQuery("SELECT * FROM risk_alerts ORDER BY id")) { boolean f = true;
                while (rs.next()) { if (!f) b.append(','); f = false;
                    b.append("{\"id\":").append(q(rs.getObject("id"))).append(",\"type\":").append(q(rs.getString("type")))
                     .append(",\"severity\":").append(q(rs.getString("severity"))).append(",\"mentor_id\":").append(q(rs.getObject("mentor_id")))
                     .append(",\"student_id\":").append(q(rs.getObject("student_id"))).append(",\"message\":").append(q(rs.getString("message")))
                     .append(",\"created_at\":").append(q(rs.getString("created_at"))).append(",\"resolved\":").append(rs.getInt("resolved") == 1).append('}'); } }
            b.append("],\"registered\":[],\"seedVersion\":");
            try (ResultSet rs = st.executeQuery("SELECT v FROM meta WHERE k='seedVersion'")) { b.append(rs.next() ? rs.getString(1) : "0"); }
            b.append('}');
            try (ResultSet rs = st.executeQuery("SELECT v FROM meta WHERE k='evalConfig'")) { if (rs.next()) b.insert(b.length() - 1, ",\"evalConfig\":" + rs.getString(1)); }
            return b.append('}').toString();
        }
    }

    /** Read-only SQL for the manager's Database tab. */
    static synchronized String runSql(String sql) {
        String t = sql.trim(); if (t.endsWith(";")) t = t.substring(0, t.length() - 1);
        if (!t.toLowerCase().startsWith("select") || t.contains(";")) return "{\"error\":\"Only a single SELECT query is allowed.\"}";
        try (Statement st = C.createStatement(); ResultSet rs = st.executeQuery(t)) {
            ResultSetMetaData md = rs.getMetaData(); int n = md.getColumnCount();
            StringBuilder b = new StringBuilder("{\"cols\":[");
            for (int i = 1; i <= n; i++) b.append(i > 1 ? "," : "").append(q(md.getColumnLabel(i)));
            b.append("],\"rows\":["); boolean f = true;
            while (rs.next()) { b.append(f ? "" : ",").append('['); f = false;
                for (int i = 1; i <= n; i++) { Object v = rs.getObject(i); String s = v instanceof String && ((String) v).length() > 60 ? ((String) v).substring(0, 57) + "..." : null;
                    b.append(i > 1 ? "," : "").append(q(s != null ? s : v)); }
                b.append(']'); }
            return b.append("]}").toString();
        } catch (SQLException e) { return "{\"error\":" + q(e.getMessage()) + "}"; }
    }

    // ---------- HTTP ----------
    static void send(HttpExchange ex, int code, String type, byte[] body) throws IOException {
        ex.getResponseHeaders().set("Content-Type", type + "; charset=utf-8"); ex.getResponseHeaders().set("Cache-Control", "no-store");
        ex.sendResponseHeaders(code, body.length); try (OutputStream o = ex.getResponseBody()) { o.write(body); }
    }
    static void handle(HttpExchange ex) throws IOException {
        String path = ex.getRequestURI().getPath();
        try {
            if (path.equals("/api/state")) {
                if (ex.getRequestMethod().equals("POST")) { saveState(new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8)); send(ex, 200, "application/json", "{\"ok\":true}".getBytes()); }
                else send(ex, 200, "application/json", loadState().getBytes(StandardCharsets.UTF_8));
            } else if (path.equals("/api/sql")) {
                String raw = ex.getRequestURI().getRawQuery(); String qs = "";
                if (raw != null) for (String p : raw.split("&")) if (p.startsWith("q=")) qs = URLDecoder.decode(p.substring(2), "UTF-8");
                send(ex, 200, "application/json", runSql(qs).getBytes(StandardCharsets.UTF_8));
            } else if (path.equals("/") || path.equals("/index.html")) {
                send(ex, 200, "text/html", Files.readAllBytes(Paths.get("web", "index.html")));
            } else send(ex, 404, "text/plain", "Not found".getBytes());
        } catch (Exception e) { e.printStackTrace(); send(ex, 500, "text/plain", String.valueOf(e).getBytes()); }
    }

    public static void main(String[] args) throws Exception {
        C = DriverManager.getConnection("jdbc:sqlite:intern_sphere_web.db"); createTables();
        HttpServer server = null; int port = 8080;
        for (; port < 8100; port++) { try { server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0); break; } catch (BindException e) { } }
        if (server == null) { System.out.println("No free port found."); return; }
        server.createContext("/", InternSphereServer::handle); server.start();
        String url = "http://localhost:" + port;
        System.out.println("\nIntern Sphere is running at  " + url + "\nDatabase file: " + new File("intern_sphere_web.db").getAbsolutePath() + "\nPress Ctrl+C to stop.");
        try { if (Desktop.isDesktopSupported()) Desktop.getDesktop().browse(new URI(url)); } catch (Throwable e) { System.out.println("Open the address above in your browser."); }
    }
}
