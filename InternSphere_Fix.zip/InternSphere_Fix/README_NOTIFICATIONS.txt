INTERN SPHERE - WINDOWS DESKTOP NOTIFICATIONS

WHAT THIS BUILD DOES
- Shows a Windows desktop toast whenever InternSphere saves a newly created in-app notification.
- The recipient does NOT need to be logged in to InternSphere, and their Edge tab may be closed.
- The event must still be created by an action in InternSphere (for example, a mentor replies or assigns a project).
- The Java server must be running in the Windows user's signed-in session. Windows must allow notifications.
- This is a shared-laptop notification: the toast appears on the Windows account running the server, regardless of which InternSphere user the notification belongs to.

ONE-TIME SETUP (Windows PowerShell)
1. Open Windows PowerShell.
2. Run: Install-Module -Name BurntToast -Scope CurrentUser
3. If asked to install NuGet or trust PSGallery, answer Yes.
4. Test: New-BurntToastNotification -Text "InternSphere", "Desktop notifications are working"

START
1. Extract this ZIP into a new folder.
2. Close any older InternSphere server window (Ctrl+C, then close it).
3. Double-click start_web.bat in this extracted folder.
4. Keep the black server window open. Open the displayed localhost address.
5. Have one InternSphere user perform an action that creates a notification for another user. The toast should appear on the laptop even if the recipient is logged out.

DIAGNOSTICS
- notification-debug.log is created beside InternSphereServer.java after the server attempts a toast.
- A line with "Toast exit=0" means PowerShell completed successfully. An error line includes the failure details.
- If no log is created, check that you started start_web.bat from this extracted folder, not an older copy.

LIMITS
- The server cannot detect a new doubt/reply/project/report event if nobody performs that action in InternSphere.
- This build does not add scheduled deadline reminders. Those need a defined reminder schedule (for example, one day before and on the due date).
- Toasts cannot be displayed while Windows is signed out or the computer is powered off.
